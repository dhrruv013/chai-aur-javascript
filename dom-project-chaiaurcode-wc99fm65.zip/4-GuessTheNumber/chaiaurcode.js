let guessField = document.querySelector('.guessField');
let guessSubmit = document.querySelector('.guessSubmit');
let form = document.querySelector('.form');
let guesses = document.querySelector('.guesses');
let lastResult = document.querySelector('.lastResult');
let lowOrHi = document.querySelector('.lowOrHi');

let correctGuess = Math.floor(Math.random() * (100 - 1 + 1) + 1);
let arr = new Array();

function newGame() {
  guessSubmit.disabled = true;
  let h1 = document.createElement('h1');
  h1.textContent = 'New Game';
  h1.style.color = 'black';
  h1.id = '';
  h1.style.backgroundColor = 'red';
  document.querySelector('.resultParas').appendChild(h1);

  // newGamebutton - click
  h1.addEventListener('click', function () {
    arr = [];
    guessSubmit.disabled = false;
    correctGuess = Math.floor(Math.random() * (100 - 1 + 1) + 1);
    guesses.textContent = ``;
    lastResult.textContent = 10;
    lowOrHi.textContent = '';
    guessField.value = '';
    document.querySelector('.resultParas').removeChild(h1);
  });
}

form.addEventListener('submit', function (e) {
  e.preventDefault();
  //Taking values
  let inputvalue = parseInt(guessField.value);
  if (inputvalue > 100 || inputvalue <= 0 || isNaN(inputvalue)) {
    lowOrHi.textContent = 'Please give a valid Input.';
    return;
  }
  addGuessEle(inputvalue);
});

function addGuessEle(ele) {
  guessField.value = '';
  arr.push(ele);
  guesses.textContent = `[${arr}]`;
  lastResult.textContent = 10 - arr.length;
  hintForGuess(ele);
  if (arr.length === 10 && ele !== correctGuess) {
    lowOrHi.textContent = `Game Over,You Lose correct ans was ${correctGuess}.`;
    newGame();
  }
}

function hintForGuess(ele) {
  if (ele > correctGuess) {
    lowOrHi.textContent = 'Guess is too big.';
  } else if (ele < correctGuess) {
    lowOrHi.textContent = 'Guess is too small.';
  } else {
    lowOrHi.textContent = `You Won, Correct guess, ans was ${correctGuess}.`;
    newGame();
  }
}
