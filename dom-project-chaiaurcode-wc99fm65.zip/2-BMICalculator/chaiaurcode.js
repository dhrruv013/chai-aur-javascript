let form = document.querySelector('form');

form.addEventListener('submit', function (e) {
  e.preventDefault();

  const height = parseInt(document.querySelector('#height').value);
  const weight = parseInt(document.querySelector('#weight').value);
  let results = document.querySelector('#results');

  if (height === '' || height < 0 || isNaN(height)) {
    results.textContent = 'Please give a valid Height.';
  } else if (weight === '' || weight < 0 || isNaN(weight)) {
    results.textContent = 'Please give a valid Weight.';
  } else {
    let ans = ((weight / (height * height)) * 10000).toFixed(2);
    results.textContent = ans;
  }
});
