let boxList = document.querySelectorAll('.button');

boxList.forEach((box) => {
  box.addEventListener('click', function (e) {
    document.body.style.backgroundColor = e.currentTarget.id; 
    // e.target.id , box.id
  });
});